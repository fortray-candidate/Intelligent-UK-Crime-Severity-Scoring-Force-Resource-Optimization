-- =====================================================================================
-- QUERY 1 : The "Silent Hotspot" Detector
-- Table   : uk_crime_incident_records
-- Technique: multi-condition HAVING clause with nested SUM(CASE ...) statements
--            (no CTEs, no window functions)
--
-- Business question
--   Which crime_type + police_force_region combinations
--     (a) leave MORE THAN 40% of their cases unresolved (outcome blank or
--         'Under investigation'), AND
--     (b) have MORE THAN 10% of their records carrying a geocoding-quality flag
--         (coordinates missing, or LSOA code missing)?
--   Crimes that are both unsolved and poorly located are the ones patrol planning
--   cannot see - a "silent" hotspot.
--
-- About the geocoding flag
--   Rows with out-of-UK coordinates or malformed LSOA codes were quarantined in Python
--   Step 2, so what remains to flag in this table is MISSING geography. Conditions are
--   written out in full (rather than using geo_quality_flag) so the logic is visible.
-- =====================================================================================
SELECT
    crime_type,
    police_force_region,
    COUNT(*)                                                         AS cases,
    ROUND(100.0 * SUM(CASE WHEN last_outcome_category IS NULL
                             OR last_outcome_category = 'Under investigation'
                           THEN 1 ELSE 0 END) / COUNT(*), 1)         AS unresolved_pct,
    ROUND(100.0 * SUM(CASE WHEN latitude IS NULL OR longitude IS NULL
                             OR lsoa_code IS NULL
                           THEN 1 ELSE 0 END) / COUNT(*), 1)         AS geo_flagged_pct
FROM uk_crime_incident_records
GROUP BY crime_type, police_force_region
HAVING SUM(CASE WHEN last_outcome_category IS NULL
                  OR last_outcome_category = 'Under investigation'
                THEN 1 ELSE 0 END) > 0.40 * COUNT(*)
   AND SUM(CASE WHEN latitude IS NULL OR longitude IS NULL
                  OR lsoa_code IS NULL
                THEN 1 ELSE 0 END) > 0.10 * COUNT(*)
ORDER BY unresolved_pct DESC, geo_flagged_pct DESC;

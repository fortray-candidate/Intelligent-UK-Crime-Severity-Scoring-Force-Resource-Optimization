-- =====================================================================================
-- QUERY 4 : The "False Severity Alarm" Audit
-- Table   : uk_crime_incident_records
-- Technique: set comparison mixing COUNT() with conditional SUM()
--
-- Business question
--   For each police force, what % of High-severity cases that reached an outcome were
--   resolved within 14 days? A fast resolution suggests the 'High' tag overstated the
--   case's real complexity (a "false severity alarm").
--
-- Definitions
--   * resolved   = an outcome month exists AND the outcome is not 'Under investigation'
--   * within 14 days = DATEDIFF(outcome_month, month) <= 14. Because both dates are the
--     1st of a month, this means the outcome was recorded in the SAME month as the crime.
--   * the brief gives no cut-off, so every force is returned, highest rate first
-- =====================================================================================
SELECT
    police_force,
    COUNT(*)                                                         AS high_cases_total,
    SUM(CASE WHEN outcome_month IS NOT NULL
              AND last_outcome_category <> 'Under investigation'
             THEN 1 ELSE 0 END)                                      AS high_cases_resolved,
    SUM(CASE WHEN outcome_month IS NOT NULL
              AND last_outcome_category <> 'Under investigation'
              AND DATEDIFF(outcome_month, month) <= 14
             THEN 1 ELSE 0 END)                                      AS resolved_within_14_days,
    ROUND(100.0 * SUM(CASE WHEN outcome_month IS NOT NULL
                            AND last_outcome_category <> 'Under investigation'
                            AND DATEDIFF(outcome_month, month) <= 14
                           THEN 1 ELSE 0 END)
          / SUM(CASE WHEN outcome_month IS NOT NULL
                      AND last_outcome_category <> 'Under investigation'
                     THEN 1 ELSE 0 END), 2)                          AS false_alarm_pct_of_resolved
FROM uk_crime_incident_records
WHERE Crime_Severity_Tier = 'High'
GROUP BY police_force
ORDER BY false_alarm_pct_of_resolved DESC;

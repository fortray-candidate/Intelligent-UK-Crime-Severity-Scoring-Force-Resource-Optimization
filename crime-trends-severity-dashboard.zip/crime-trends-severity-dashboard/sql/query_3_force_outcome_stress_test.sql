-- =====================================================================================
-- QUERY 3 : Force Outcome Stress Test
-- Table   : uk_crime_incident_records
-- Technique: cross-conditional aggregation ("pivoting") in SELECT and HAVING
--
-- Business question
--   For each police force, what is the average number of days between a crime's
--   reported month and its outcome month, split by Crime_Severity_Tier? Return only
--   forces where High-severity cases take MORE THAN 30 DAYS LONGER than Low-severity.
--
-- Notes
--   * month and outcome_month are both stored as the 1st of the month, so DATEDIFF
--     returns whole-month steps (about 30 days each).
--   * DATEDIFF(later, earlier) is MySQL/MariaDB/SQL Server-style. PostgreSQL: outcome_month - month.
--     SQLite: julianday(outcome_month) - julianday(month). (run_sql_queries.py emulates DATEDIFF on SQLite.)
--   * rows with no outcome_month yield NULL and are ignored by AVG().
-- =====================================================================================
SELECT
    police_force,
    ROUND(AVG(CASE WHEN Crime_Severity_Tier = 'High'   THEN DATEDIFF(outcome_month, month) END), 1) AS avg_days_high,
    ROUND(AVG(CASE WHEN Crime_Severity_Tier = 'Medium' THEN DATEDIFF(outcome_month, month) END), 1) AS avg_days_medium,
    ROUND(AVG(CASE WHEN Crime_Severity_Tier = 'Low'    THEN DATEDIFF(outcome_month, month) END), 1) AS avg_days_low,
    ROUND(AVG(CASE WHEN Crime_Severity_Tier = 'High'   THEN DATEDIFF(outcome_month, month) END)
        - AVG(CASE WHEN Crime_Severity_Tier = 'Low'    THEN DATEDIFF(outcome_month, month) END), 1) AS high_minus_low_days
FROM uk_crime_incident_records
GROUP BY police_force
HAVING AVG(CASE WHEN Crime_Severity_Tier = 'High' THEN DATEDIFF(outcome_month, month) END)
     - AVG(CASE WHEN Crime_Severity_Tier = 'Low'  THEN DATEDIFF(outcome_month, month) END) > 30
ORDER BY high_minus_low_days DESC;

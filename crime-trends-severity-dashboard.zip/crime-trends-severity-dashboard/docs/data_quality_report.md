# Data-quality & pipeline run report

_Generated automatically by `run_pipeline.py` on 10 Nov 2026 14:33._

Every cleaning decision below is counted, so nothing happens silently.


## STEP 1 ingest

- raw rows read: 100,000
- raw columns: 16
- exact duplicate rows removed: 600
- crime_id blank -> NULL: 967
- force names standardised (distinct raw spellings in reported_by): 137
- reported_by differs from falls_within (flagged, kept): 2,769
- police_force_region re-derived from the standardised force (raw value was wrong): 1,961
- month values unparseable -> NULL: 0
- rows with an ambiguous DD/MM vs MM/DD reported_date: 13,865
-   settled using the month column: 13,865
-   both readings identical or no evidence -> UK DD/MM: 0
- reported_date whose month disagrees with the month column (kept, flagged): 0
- reported_date invalid strings (TBC, N/A, 31/02/2024 ...) -> NULL: 587
- reported_date blank -> NULL: 1,970
- longitude blank -> NULL: 4,031
- latitude blank -> NULL: 3,991
- LSOA codes upper-cased (e01... -> E01...): 2,927
- crime_type spellings standardised (distinct raw -> 14 categories): 116
- victim_type blank (not recorded) -> NULL: 14,906
- context column is 100% blank -> dropped: 1
- rows sharing a crime_id with a different row (flagged, kept): 588
- rows leaving Step 1: 99,400

## STEP 2 anomaly filter

- rows failing COORDINATES_OUTSIDE_UK: 1,805
- rows failing MALFORMED_LSOA_CODE: 2,887
- rows failing both rules: 49
- blank coordinates kept (flagged later): 7,842
- blank LSOA codes kept (flagged later): 3,061
- rows quarantined: 4,643
- rows continuing to the main dataset: 94,757
- quarantine file written -> quarantined_crime_data.csv

## STEP 3 severity

- Crime_Severity_Tier = High: 23,076
- Crime_Severity_Tier = Medium: 25,811
- Crime_Severity_Tier = Low: 45,870

## STEP 4 features

- average Case_Escalation_Score: 67.01
- force CV of monthly counts: min 7.8%  max 11.8%  (most volatile: West Midlands Police, steadiest: Cheshire Police)
- months in the data window: 44
- unresolved cases (%): 35.03
- records with a geocoding-quality flag (%): 10.83

## STEP 5 database

- clean CSV written -> data/processed/crime_trends_clean.csv
- connecting to database (sqlite)
- rows loaded into uk_crime_incident_records: 94,757

## STEP 6 findings

- headline metrics saved -> reports/headline_metrics.json
- figure saved -> docs/figures/01_severity_time_to_outcome_vs_unresolved.png
- figure saved -> docs/figures/02_monthly_crimes_and_unresolved.png
- figure saved -> docs/figures/03_crime_type_by_region_heatmap.png
- figure saved -> docs/figures/04_force_volatility_index.png
- Power BI cross-check files saved -> powerbi/expected_values_*

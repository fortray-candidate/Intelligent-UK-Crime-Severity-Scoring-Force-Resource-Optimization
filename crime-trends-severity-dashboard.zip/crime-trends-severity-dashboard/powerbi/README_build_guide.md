# Power BI build guide - Crime Trends Command Centre

> **Why there is no `.pbix` in this folder:** a `.pbix` is a binary file that can only be saved from
> Power BI Desktop (Windows). Everything needed to build it in about **45-60 minutes** is here: the
> data-load script, every DAX measure, a colour theme, a visual-by-visual layout and the numbers
> your finished dashboard must show. When you are done, save your file as
> `powerbi/Crime_Trends_Command_Centre.pbix` and add screenshots to `powerbi/screenshots/`.

| File | What it is |
|---|---|
| `01_power_query_load.m` | Power Query (M) - loads the single flat table `Fact_Crime_Incidents` |
| `02_dax_measures.dax` | All DAX: KPIs, month-on-month trend, smart narrative, alert colour, what-if simulation |
| `theme_crime_trends.json` | Colour theme (View > Themes > Browse for themes) |
| `expected_values_by_force.csv` / `expected_values_network.json` | Independent Python results to check your dashboard against |

## 1. Load the data (5 min)

1. Run `python python/run_pipeline.py` so `data/processed/crime_trends_clean.csv` exists.
2. Power BI Desktop -> **Home -> Get data -> Blank query -> Advanced Editor**, paste `01_power_query_load.m`,
   change `FilePath`, click **Done**.
3. Rename the query **`Fact_Crime_Incidents`** -> **Close & Apply**.

No star schema and no `Dim_Date`: one flat fact table. Time analysis uses the built-in date hierarchy on `month`;
the map plots `latitude` / `longitude` straight from the fact table.

## 2. Tidy the model (5 min)

| Column | Setting |
|---|---|
| `Crime_Severity_Tier` | **Sort by column -> `tier_sort`** (High, Medium, Low) |
| `latitude` | Data category **Latitude**, summarisation **Don't summarize** |
| `longitude` | Data category **Longitude**, summarisation **Don't summarize** |
| `Case_Escalation_Score`, `Force_Crime_Volatility_Index` | Summarisation **Average** |
| `*_flag`, `tier_sort`, `record_id`, `source_row_number` | Hide in report view |

## 3. Create the what-if parameter and measures (10 min)

1. **Modeling -> New parameter -> Numeric range:** `Additional Patrol Resourcing`, Min `0.05`, Max `0.25`,
   Increment `0.01`, Default `0.10`, *Add slicer*. Format as **Percentage**.
2. Paste every measure from `02_dax_measures.dax` (skip `Additional Patrol Resourcing Value` if Power BI
   already generated it).
3. **View -> Themes -> Browse for themes -> `theme_crime_trends.json`.**

## 4. Build the page (20-30 min) - 16:9, rename the page **Command Centre**

```
+----------------------------------------------------------------------------------+
|  TITLE: UK Crime Trends - Command Centre                                          |
+------------+------------+------------+-------------------------------------------+
| Region     | Force      | Severity   |  Smart narrative (text card)              |
| slicer     | slicer     | tier slicer| + Victim type slicer                      |
+------------+------------+------------+-------------------------------------------+
| KPI 1      | KPI 2      | KPI 3      | KPI 4 *alert*      | KPI 5 + patrol slider |
| Total      | % Unresolved| MoM change | Avg escalation     | Projected High cases  |
| crimes     |            |            |                    | resolved              |
+------------+------------+------------+--------------------+-----------------------+
|  LINE: crimes + % unresolved by month | MAP (lat/long)  | MATRIX HEATMAP         |
|                                       |                 | crime_type x region    |
+---------------------------------------+-----------------+------------------------+
```

| # | Visual | Fields | Notes |
|---|---|---|---|
| 1 | Slicer (Dropdown) | `police_force_region` | |
| 2 | Slicer (Dropdown) | `police_force` | Single-select gives the force-specific narrative |
| 3 | Slicer (Tile) | `Crime_Severity_Tier` | The **recalculated** tier |
| 4 | Slicer (Tile) | `victim_type` | ~15% show "Not recorded" |
| 5 | Card | `[Total Crimes]` | |
| 6 | Card | `[% Unresolved]` | 0.0% |
| 7 | Card | `[Crime MoM Change %]` | Format `+0.0%;-0.0%` |
| 8 | Card (alert) | `[Avg Escalation Score]` | Conditional colour - section 6 |
| 9 | Card | `[Projected High-Severity Cases Resolved]` | Format `#,0` |
| 10 | What-if slider | `Additional Patrol Resourcing` | |
| 11 | **Line chart** | X = `month` (date hierarchy, Month level). Y = `[Total Crimes]`. Secondary Y = `[% Unresolved]` | If no secondary-axis well: use *Line and clustered column chart* with both measures as lines |
| 12 | **Map** (Azure Maps or Map) | Latitude = `latitude`, Longitude = `longitude`, Legend = `Crime_Severity_Tier`, Size = `[Total Crimes]` | 94k points exceed the classic Map visual's limit - add a visual filter `Crime_Severity_Tier = High`, or use Azure Maps |
| 13 | **Matrix** | Rows = `crime_type`; Columns = `police_force_region`; Values = `[Total Crimes]` | Cell elements -> Background colour -> Gradient (white to red) = the **heatmap**. Add a second matrix or tooltip using `[% Unresolved]` to show where *severity* concentrates |
| 14 | Card (text) | `[Force Trend Narrative]` | Wide card, word-wrap on |

## 5. Smart narrative (the "Text Generation Measure")

`[Force Trend Narrative]` builds a sentence from DAX variables. Select **Durham Constabulary** in the force slicer:

> *Durham Constabulary: recorded crime is rising (+29.2% month-on-month, 124 crimes in Aug 2026 vs 96 the
> month before). 34.5% of cases are unresolved, and the most frequent unresolved crime type is
> 'Violence and sexual offences' with 341 open cases.*

With no selection it describes the whole network.

## 6. Multi-condition KPI alert (Red only if BOTH are true)

Select visual 8 -> **Format -> Callout value -> Font colour -> fx -> Format style = Field value** -> `[KPI Alert Colour]`.
It returns red only when the force's average `Case_Escalation_Score` is **above the network average (67.01)**
**and** its `Force_Crime_Volatility_Index` is **above the network average (10.09)**. Test on a scratch page
with a table of `police_force`, `[Avg Escalation Score]`, `[Avg Volatility Index]`, `[KPI Is Critical]` - exactly
**six forces** should be critical: Metropolitan, Police Scotland, PSNI, South Yorkshire, West Midlands, West Yorkshire.

## 7. What-if simulation

Slide **Additional Patrol Resourcing** from 5% to 25%:
`[Projected High-Severity Cases Resolved]` = High-severity unresolved backlog x slider %, and
`[Projected High-Severity Backlog Remaining]`, `[Projected % Unresolved (All Cases)]` update instantly.

## 8. Check your numbers (important)

With **no slicer selected**:

| Measure | Expected |
|---|---|
| Total Crimes | **94,757** |
| % Unresolved | **35.03%** |
| Latest month (Aug 2026) crimes / previous month | **2,245 / 2,133** (+5.3%) |
| Network avg Case_Escalation_Score | **67.01** |
| Network avg Force_Crime_Volatility_Index | **10.09** |
| High-Severity Backlog | **8,196** |
| Projected High-Severity Cases Resolved @ 5% / 10% / 25% | **409.8 / 819.6 / 2,049** (card shows 410 / 820 / 2,049) |

Per-force values (incl. the six red forces) are in `expected_values_by_force.csv`.

## 9. Known quirk: the map

The coordinates in this synthetic dataset fill an almost perfect rectangle (lat 49-61, lon -8.5 to 1.6) and are
**not tied to the police force**: 53.6% of Police Scotland cases sit south of 54.6 degrees N. So the map will not
trace UK coastlines or force areas. Build it as specified, and mention this in your write-up - spotting it
is part of the analysis.

## 10. Export for the portfolio

**File -> Save as** `Crime_Trends_Command_Centre.pbix` here; **Export -> PDF** to `screenshots/dashboard.pdf`;
screenshots of the default view, one force selected (narrative + alert), slider at 5% and 25%.

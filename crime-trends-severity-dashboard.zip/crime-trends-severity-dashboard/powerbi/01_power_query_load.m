// =====================================================================================
// POWER QUERY (M) - loads the single flat fact table  Fact_Crime_Incidents
//
// HOW TO USE
//   Power BI Desktop > Home > Get data > Blank query > Advanced Editor >
//   delete everything > paste this whole file > change FilePath > Done.
//   Rename the query to  Fact_Crime_Incidents  and click Close & Apply.
//   (Prefer MySQL? See OPTION B at the bottom.)
// =====================================================================================
let
    // ---- 1. EDIT THIS LINE: full path to the CSV produced by the Python pipeline ----
    FilePath = "C:\Users\YOU\Documents\crime-trends-severity-dashboard\data\processed\crime_trends_clean.csv",

    Source   = Csv.Document(File.Contents(FilePath), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),

    // ---- 2. explicit data types (en-US culture = '.' decimal point) -------------------
    Typed = Table.TransformColumnTypes(Promoted, {
        {"record_id", Int64.Type}, {"source_row_number", Int64.Type},
        {"crime_id", type text},
        {"month", type date}, {"reported_date", type date}, {"outcome_month", type date},
        {"police_force", type text}, {"falls_within", type text}, {"police_force_region", type text},
        {"longitude", type number}, {"latitude", type number},
        {"location", type text}, {"lsoa_code", type text}, {"lsoa_name", type text},
        {"crime_type", type text}, {"last_outcome_category", type text}, {"victim_type", type text},
        {"force_mismatch_flag", Int64.Type}, {"region_corrected_flag", Int64.Type},
        {"duplicate_crime_id_flag", Int64.Type},
        {"Crime_Severity_Tier", type text}, {"Case_Escalation_Score", Int64.Type},
        {"Force_Crime_Volatility_Index", type number},
        {"unresolved_flag", Int64.Type}, {"geo_quality_flag", Int64.Type}, {"days_to_outcome", Int64.Type}
    }, "en-US"),

    // ---- 3. friendly text columns -----------------------------------------------------
    AddStatus = Table.AddColumn(Typed, "case_status",
        each if [unresolved_flag] = 1 then "Unresolved" else "Resolved / outcome recorded", type text),

    // ---- 4. sort helper so tiers always read High > Medium > Low ----------------------
    AddTierSort = Table.AddColumn(AddStatus, "tier_sort",
        each if [Crime_Severity_Tier] = "High" then 1 else if [Crime_Severity_Tier] = "Medium" then 2 else 3, Int64.Type),

    // ---- 5. victim_type is blank for ~15% of rows: show it as a label, not (Blank) ----
    FillVictim = Table.ReplaceValue(AddTierSort, null, "Not recorded", Replacer.ReplaceValue, {"victim_type"})
in
    FillVictim


// =====================================================================================
// OPTION B - load straight from MySQL (table created by step5_load_db.py)
//
// let
//     Source = MySQL.Database("localhost", "portfolio"),
//     Table  = Source{[Schema = "portfolio", Item = "uk_crime_incident_records"]}[Data],
//     AddStatus = Table.AddColumn(Table, "case_status",
//         each if [unresolved_flag] = 1 then "Unresolved" else "Resolved / outcome recorded", type text),
//     AddTierSort = Table.AddColumn(AddStatus, "tier_sort",
//         each if [Crime_Severity_Tier] = "High" then 1 else if [Crime_Severity_Tier] = "Medium" then 2 else 3, Int64.Type),
//     FillVictim = Table.ReplaceValue(AddTierSort, null, "Not recorded", Replacer.ReplaceValue, {"victim_type"})
// in
//     FillVictim
// (MySQL needs the "MySQL Connector/NET" driver installed once on your PC.)
// =====================================================================================

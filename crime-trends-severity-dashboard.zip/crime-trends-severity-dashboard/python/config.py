"""
Central settings for the UK Crime Trends pipeline.
Change values here - nothing else in the code needs editing.
"""
import os
from pathlib import Path

# ---------------------------------------------------------------- paths
PROJECT_ROOT = Path(__file__).resolve().parents[1]
RAW_CSV = PROJECT_ROOT / "data" / "raw" / "crime_trends_uk_dataset.csv"
CLEAN_CSV = PROJECT_ROOT / "data" / "processed" / "crime_trends_clean.csv"
QUARANTINE_CSV = PROJECT_ROOT / "quarantined_crime_data.csv"
REPORTS_DIR = PROJECT_ROOT / "reports"
FIGURES_DIR = PROJECT_ROOT / "docs" / "figures"
SQL_DIR = PROJECT_ROOT / "sql"
SQL_RESULTS_DIR = SQL_DIR / "results"

# ---------------------------------------------------------------- database
# Default = a local SQLite file (zero set-up). To load into MySQL instead, set
# an environment variable BEFORE running:
#   PowerShell :  $env:DB_URL = "mysql+pymysql://USER:PASSWORD@localhost:3306/portfolio"
#   Mac/Linux  :  export DB_URL="mysql+pymysql://USER:PASSWORD@localhost:3306/portfolio"
# (create the empty database first:  CREATE DATABASE portfolio;)
DB_URL = os.getenv("DB_URL", f"sqlite:///{PROJECT_ROOT / 'data' / 'crime_trends.db'}")
TABLE_NAME = "uk_crime_incident_records"

# ---------------------------------------------------------------- geography rules (Step 2)
UK_LAT_MIN, UK_LAT_MAX = 49.0, 61.0
UK_LON_MIN, UK_LON_MAX = -8.5, 2.0
LSOA_PATTERN = r"E01\d{6}"          # 'E01' followed by exactly six digits

# ---------------------------------------------------------------- scoring rules (Step 4)
ESCALATION_BASE = 50
ESCALATION_HIGH_BONUS = 30
ESCALATION_MEDIUM_BONUS = 15
ESCALATION_UNRESOLVED_BONUS = 20
ESCALATION_BUSINESS_PENALTY = 10

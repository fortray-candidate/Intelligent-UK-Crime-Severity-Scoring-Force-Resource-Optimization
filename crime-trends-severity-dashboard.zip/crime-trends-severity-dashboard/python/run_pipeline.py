"""
RUN THE WHOLE PIPELINE
======================
    python python/run_pipeline.py

Steps:  1 ingest & clean  ->  2 quarantine impossible rows  ->  3 severity tiers
        ->  4 engineer features  ->  5 load database  ->  6 charts & headline numbers
Everything printed here is also saved to docs/data_quality_report.md
"""
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # so the step files can be imported

import config
import step1_ingest
import step2_anomaly_filter
import step3_severity
import step4_features
import step5_load_db
import step6_findings
from pipeline_log import log


def write_quality_report():
    lines = ["# Data-quality & pipeline run report", "",
             f"_Generated automatically by `run_pipeline.py` on {datetime.now():%d %b %Y %H:%M}._", "",
             "Every cleaning decision below is counted, so nothing happens silently.", ""]
    current = None
    for step, message in log.entries:
        if step != current:
            lines += ["", f"## {step}", ""]
            current = step
        lines.append(f"- {message}")
    out = config.PROJECT_ROOT / "docs" / "data_quality_report.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"\nData-quality report written -> {out.relative_to(config.PROJECT_ROOT)}")


def main():
    started = time.time()
    df, raw = step1_ingest.run()
    df, _audit = step2_anomaly_filter.run(df, raw)
    df = step3_severity.run(df)
    df = step4_features.run(df)
    df = step5_load_db.run(df)
    step6_findings.run(df)
    step6_findings.export_powerbi_checks(df)
    write_quality_report()
    print(f"\nPipeline finished in {time.time() - started:.0f} seconds.")


if __name__ == "__main__":
    main()

"""
STEP 3 - Standardisation & Severity-tier recalculation
=======================================================
After crime_type spellings are standardised (Step 1), every category rolls up
to one of three operational severity tiers using a canonical mapping:

  High    Robbery | Violence and sexual offences | Possession of weapons
  Medium  Burglary | Vehicle crime | Criminal damage and arson | Drugs
  Low     Anti-social behaviour | Bicycle theft | Shoplifting | Other theft |
          Public order | Theft from the person | Other crime
"""
import pandas as pd

from pipeline_log import log

STEP = "STEP 3 severity"

SEVERITY_MAP = {
    "Robbery": "High", "Violence and sexual offences": "High", "Possession of weapons": "High",
    "Burglary": "Medium", "Vehicle crime": "Medium", "Criminal damage and arson": "Medium", "Drugs": "Medium",
    "Anti-social behaviour": "Low", "Bicycle theft": "Low", "Shoplifting": "Low", "Other theft": "Low",
    "Public order": "Low", "Theft from the person": "Low", "Other crime": "Low",
}


def run(df):
    df["Crime_Severity_Tier"] = df["crime_type"].map(SEVERITY_MAP)          # vectorised lookup
    unmapped = int(df["Crime_Severity_Tier"].isna().sum())
    assert unmapped == 0, f"{unmapped} rows have a crime_type with no severity tier"
    for tier in ["High", "Medium", "Low"]:
        log.metric(STEP, f"Crime_Severity_Tier = {tier}", int((df["Crime_Severity_Tier"] == tier).sum()))
    return df

"""
Runs every sql/query_*.sql file against the database set in config.py and saves
each result set as a CSV in sql/results/. Handy for (a) checking the queries work
on your machine and (b) pasting real numbers into the README.

    python python/run_sql_queries.py
"""
import re
import time
from datetime import date, datetime

import pandas as pd
from sqlalchemy import create_engine, event, text

import config


def split_statements(sql_text):
    """Drop '-- comment' lines, then split on ';'."""
    no_comments = "\n".join(line for line in sql_text.splitlines() if not line.strip().startswith("--"))
    return [s.strip() for s in no_comments.split(";") if s.strip()]


def main():
    engine = create_engine(config.DB_URL)

    if engine.dialect.name == "sqlite":          # lets SQLite understand MySQL's DATEDIFF(a, b)
        @event.listens_for(engine, "connect")
        def _register(dbapi_conn, _):
            def datediff(a, b):
                if a is None or b is None:
                    return None
                fa = datetime.strptime(str(a)[:10], "%Y-%m-%d").date()
                fb = datetime.strptime(str(b)[:10], "%Y-%m-%d").date()
                return (fa - fb).days
            dbapi_conn.create_function("DATEDIFF", 2, datediff)

    config.SQL_RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    for sql_file in sorted(config.SQL_DIR.glob("query_*.sql")):
        for n, statement in enumerate(split_statements(sql_file.read_text(encoding="utf-8")), start=1):
            started = time.time()
            with engine.connect() as conn:
                result = pd.read_sql(text(statement), conn)
            out = config.SQL_RESULTS_DIR / f"{sql_file.stem}__part{n}.csv"
            result.to_csv(out, index=False)
            print(f"{sql_file.name:<52} part {n}: {len(result):>6,} rows  ({time.time() - started:5.1f}s) -> {out.name}")


if __name__ == "__main__":
    main()

"""
STEP 1 - Robust data ingestion & transformation
================================================
Reads the raw CSV (every column as text, so nothing is silently changed) and:

  * removes exact duplicate rows
  * standardises force names, crime types and every other variant spelling
  * re-derives police_force_region from the standardised force name
  * converts the mixed month / reported_date / outcome_month formats into real dates
    (ambiguous 05/06/2024-style dates are settled using the row's own `month` column)
  * enforces numeric latitude / longitude
  * upper-cases LSOA codes (e01030134 -> E01030134)

Nothing is *deleted* here except exact duplicates. Geographically impossible
records are separated in Step 2.
"""
import numpy as np
import pandas as pd

import config
from pipeline_log import log

STEP = "STEP 1 ingest"

# {Clean label: [every spelling seen in the raw file, lower-case]}
FORCE_MAP = {
    "Avon and Somerset Police": ["avon and somerset police"],
    "Cheshire Police": ["cheshire police"],
    "Durham Constabulary": ["durham constabulary"],
    "Essex Police": ["essex police"],
    "Greater Manchester Police": ["greater manchester police", "gtr manchester police", "gmp"],
    "Hampshire Police": ["hampshire police"],
    "Kent Police": ["kent police"],
    "Lancashire Police": ["lancashire police"],
    "Leicestershire Police": ["leicestershire police"],
    "Merseyside Police": ["merseyside police"],
    "Metropolitan Police": ["metropolitan police", "met police", "met", "mps"],
    "Northumbria Police": ["northumbria police"],
    "Nottinghamshire Police": ["nottinghamshire police"],
    "Police Scotland": ["police scotland"],
    "Police Service of Northern Ireland": ["police service of northern ireland"],
    "South Wales Police": ["south wales police"],
    "South Yorkshire Police": ["south yorkshire police"],
    "Thames Valley Police": ["thames valley police", "thames valley", "tvp"],
    "West Midlands Police": ["west midlands police", "w midlands police"],
    "West Yorkshire Police": ["west yorkshire police"],
}
# Broader region each force sits in
FORCE_TO_REGION = {
    "Avon and Somerset Police": "South West", "Cheshire Police": "North West",
    "Durham Constabulary": "North East", "Essex Police": "East of England",
    "Greater Manchester Police": "North West", "Hampshire Police": "South East",
    "Kent Police": "South East", "Lancashire Police": "North West",
    "Leicestershire Police": "East Midlands", "Merseyside Police": "North West",
    "Metropolitan Police": "London", "Northumbria Police": "North East",
    "Nottinghamshire Police": "East Midlands", "Police Scotland": "Scotland",
    "Police Service of Northern Ireland": "Northern Ireland", "South Wales Police": "Wales",
    "South Yorkshire Police": "Yorkshire and the Humber", "Thames Valley Police": "South East",
    "West Midlands Police": "West Midlands", "West Yorkshire Police": "Yorkshire and the Humber",
}
CRIME_TYPE_MAP = {
    "Anti-social behaviour": ["anti-social behaviour", "anti social behaviour", "antisocial behaviour", "asb"],
    "Bicycle theft": ["bicycle theft"],
    "Burglary": ["burglary"],
    "Criminal damage and arson": ["criminal damage and arson", "criminal damage & arson"],
    "Drugs": ["drugs"],
    "Other crime": ["other crime"],
    "Other theft": ["other theft"],
    "Possession of weapons": ["possession of weapons"],
    "Public order": ["public order"],
    "Robbery": ["robbery"],
    "Shoplifting": ["shoplifting"],
    "Theft from the person": ["theft from the person"],
    "Vehicle crime": ["vehicle crime", "auto crime"],
    "Violence and sexual offences": ["violence and sexual offences", "violence & sexual offences"],
}
VICTIM_TYPES = {"Individual": ["individual"], "Business": ["business"], "Public/Community": ["public/community"]}


def _invert(mapping):
    return {variant: clean for clean, variants in mapping.items() for variant in variants}


def standardise(series, mapping, column):
    key = series.str.strip().str.lower()
    out = key.map(_invert(mapping))
    unmapped = int((out.isna() & key.ne("")).sum())
    if unmapped:
        log.info(STEP, f"WARNING {column}: {unmapped} values not in mapping -> NULL")
    return out


def blank_to_null(series):
    s = series.str.strip()
    return s.where(s.ne(""))


# ----------------------------------------------------------------------------
# months  (2024-06 | 2024/06 | 06-2024 | June 2024)
# ----------------------------------------------------------------------------
def parse_month(series):
    s = series.str.strip()
    out = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")
    for pattern, fmt in ((r"\d{4}-\d{2}", "%Y-%m"), (r"\d{4}/\d{2}", "%Y/%m"),
                         (r"\d{2}-\d{4}", "%m-%Y"), (r"[A-Za-z]+ \d{4}", "%B %Y")):
        mask = s.str.fullmatch(pattern)
        if mask.any():
            parsed = pd.to_datetime(s[mask], format=fmt, errors="coerce").astype("datetime64[ns]")
            out = out.where(~mask, parsed.reindex(out.index))
    return out


# ----------------------------------------------------------------------------
# full dates (ISO | 31-Dec-2024 | 31.12.2024 | 31/12/2024 or 12/31/2024)
# ----------------------------------------------------------------------------
def _date_candidates(series):
    """Two readings (A = DD/MM, B = MM/DD). Unambiguous formats give A == B; impossible readings are NaT."""
    s = series.str.strip()
    exact = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")
    for pattern, fmt in ((r"\d{4}-\d{2}-\d{2}", "%Y-%m-%d"),
                         (r"\d{2}-[A-Za-z]{3}-\d{4}", "%d-%b-%Y"),
                         (r"\d{2}\.\d{2}\.\d{4}", "%d.%m.%Y")):
        mask = s.str.fullmatch(pattern)
        if mask.any():
            parsed = pd.to_datetime(s[mask], format=fmt, errors="coerce").astype("datetime64[ns]")
            exact = exact.where(~mask, parsed.reindex(exact.index))
    parts = s.str.extract(r"^(\d{2})/(\d{2})/(\d{4})$").apply(pd.to_numeric)
    is_slash = parts[0].notna()
    dmy = pd.to_datetime({"year": parts[2], "month": parts[1], "day": parts[0]}, errors="coerce").astype("datetime64[ns]")
    mdy = pd.to_datetime({"year": parts[2], "month": parts[0], "day": parts[1]}, errors="coerce").astype("datetime64[ns]")
    return exact.where(~is_slash, dmy), exact.where(~is_slash, mdy)


def parse_reported_date(raw_dates, month):
    """
    Ambiguous slash dates are settled with the row's own `month` column: pick the
    reading whose year-month equals `month` (verified: 100% of unambiguous dates match
    their month column). If the evidence is not decisive, DD/MM (UK convention) is used.
    """
    a, b = _date_candidates(raw_dates)
    ambiguous = a.notna() & b.notna() & (a != b)
    a_fits = (a.dt.year == month.dt.year) & (a.dt.month == month.dt.month)
    b_fits = (b.dt.year == month.dt.year) & (b.dt.month == month.dt.month)
    chosen = a.fillna(b)                                       # DD/MM first, else the only valid reading
    use_b = ambiguous & b_fits & ~a_fits
    chosen = chosen.where(~use_b, b)
    log.metric(STEP, "rows with an ambiguous DD/MM vs MM/DD reported_date", int(ambiguous.sum()))
    log.metric(STEP, "  settled using the month column", int((ambiguous & (a_fits ^ b_fits)).sum()))
    log.metric(STEP, "  both readings identical or no evidence -> UK DD/MM", int((ambiguous & ~(a_fits ^ b_fits)).sum()))
    mismatch = chosen.notna() & month.notna() & ((chosen.dt.year != month.dt.year) | (chosen.dt.month != month.dt.month))
    log.metric(STEP, "reported_date whose month disagrees with the month column (kept, flagged)", int(mismatch.sum()))
    return chosen, mismatch


def run():
    raw = pd.read_csv(config.RAW_CSV, dtype=str, keep_default_na=False)
    raw.insert(0, "source_row_number", np.arange(2, len(raw) + 2))
    log.metric(STEP, "raw rows read", len(raw))
    log.metric(STEP, "raw columns", raw.shape[1] - 1)

    data_cols = [c for c in raw.columns if c != "source_row_number"]
    dupes = raw.duplicated(subset=data_cols, keep="first")
    log.metric(STEP, "exact duplicate rows removed", int(dupes.sum()))
    kept = raw.loc[~dupes].copy()

    df = pd.DataFrame(index=kept.index)
    df["source_row_number"] = kept["source_row_number"]
    df["crime_id"] = blank_to_null(kept["crime_id"])
    log.metric(STEP, "crime_id blank -> NULL", int(df["crime_id"].isna().sum()))

    # ---- forces & region -----------------------------------------------------------------
    df["police_force"] = standardise(kept["reported_by"], FORCE_MAP, "reported_by")
    df["falls_within"] = standardise(kept["falls_within"], FORCE_MAP, "falls_within")
    df["force_mismatch_flag"] = (df["police_force"] != df["falls_within"]).astype(int)
    log.metric(STEP, "force names standardised (distinct raw spellings in reported_by)", int(kept["reported_by"].nunique()))
    log.metric(STEP, "reported_by differs from falls_within (flagged, kept)", int(df["force_mismatch_flag"].sum()))

    raw_region = kept["police_force_region"].str.strip()
    df["police_force_region"] = df["police_force"].map(FORCE_TO_REGION)
    df["region_corrected_flag"] = (raw_region != df["police_force_region"]).astype(int)
    log.metric(STEP, "police_force_region re-derived from the standardised force (raw value was wrong)",
               int(df["region_corrected_flag"].sum()))

    # ---- dates ---------------------------------------------------------------------------
    df["month"] = parse_month(kept["month"])
    df["outcome_month"] = parse_month(kept["outcome_month"])
    log.metric(STEP, "month values unparseable -> NULL", int((df["month"].isna() & kept["month"].str.strip().ne("")).sum()))
    df["reported_date"], _mismatch = parse_reported_date(kept["reported_date"], df["month"])
    invalid = int((kept["reported_date"].str.strip().ne("") & df["reported_date"].isna()).sum())
    log.metric(STEP, "reported_date invalid strings (TBC, N/A, 31/02/2024 ...) -> NULL", invalid)
    log.metric(STEP, "reported_date blank -> NULL", int(kept["reported_date"].str.strip().eq("").sum()))

    # ---- coordinates -----------------------------------------------------------------------
    df["longitude"] = pd.to_numeric(kept["longitude"], errors="coerce")
    df["latitude"] = pd.to_numeric(kept["latitude"], errors="coerce")
    log.metric(STEP, "longitude blank -> NULL", int(df["longitude"].isna().sum()))
    log.metric(STEP, "latitude blank -> NULL", int(df["latitude"].isna().sum()))

    # ---- text columns ----------------------------------------------------------------------
    df["location"] = blank_to_null(kept["location"])
    lsoa_raw = blank_to_null(kept["lsoa_code"])
    df["lsoa_code"] = lsoa_raw.str.upper()
    log.metric(STEP, "LSOA codes upper-cased (e01... -> E01...)", int((lsoa_raw.notna() & (lsoa_raw != df["lsoa_code"])).sum()))
    df["lsoa_name"] = blank_to_null(kept["lsoa_name"])
    df["crime_type"] = standardise(kept["crime_type"], CRIME_TYPE_MAP, "crime_type")
    log.metric(STEP, "crime_type spellings standardised (distinct raw -> 14 categories)", int(kept["crime_type"].nunique()))
    df["last_outcome_category"] = blank_to_null(kept["last_outcome_category"])
    df["victim_type"] = standardise(kept["victim_type"], VICTIM_TYPES, "victim_type")
    log.metric(STEP, "victim_type blank (not recorded) -> NULL", int(df["victim_type"].isna().sum()))
    log.metric(STEP, "context column is 100% blank -> dropped", int(kept["context"].str.strip().eq("").all()))

    df["duplicate_crime_id_flag"] = (df["crime_id"].notna() & df["crime_id"].duplicated(keep=False)).astype(int)
    log.metric(STEP, "rows sharing a crime_id with a different row (flagged, kept)", int(df["duplicate_crime_id_flag"].sum()))

    ordered = ["source_row_number", "crime_id", "month", "reported_date", "police_force", "falls_within",
               "police_force_region", "longitude", "latitude", "location", "lsoa_code", "lsoa_name", "crime_type",
               "last_outcome_category", "outcome_month", "victim_type",
               "force_mismatch_flag", "region_corrected_flag", "duplicate_crime_id_flag"]
    df = df[ordered].reset_index(drop=True)
    log.metric(STEP, "rows leaving Step 1", len(df))
    return df, raw

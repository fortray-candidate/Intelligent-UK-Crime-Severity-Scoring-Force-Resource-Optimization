"""
STEP 6 - Companion charts & headline numbers (optional but handy)
==================================================================
Re-creates the key findings with Python so you can (a) paste numbers into the
README and (b) cross-check the Power BI dashboard against an independent
calculation. Charts -> docs/figures/ ; numbers -> reports/headline_metrics.json ;
Power BI expected values -> powerbi/expected_values_*.

NOTE: these are Python (matplotlib) charts - they are NOT Power BI screenshots.
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config
from pipeline_log import log

STEP = "STEP 6 findings"
NAVY, TEAL, ORANGE, RED, GREY = "#1F3A5F", "#2A9D8F", "#F4A261", "#E63946", "#8D99AE"
TIER_COLOURS = {"High": RED, "Medium": ORANGE, "Low": TEAL}
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "figure.dpi": 130})


def _save(fig, name):
    config.FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(config.FIGURES_DIR / name, bbox_inches="tight")
    plt.close(fig)
    log.info(STEP, f"figure saved -> docs/figures/{name}")


def run(df):
    m = {}
    tiers = ["High", "Medium", "Low"]
    m["rows_in_main_table"] = int(len(df))
    m["months_in_window"] = int(df["month"].nunique())
    m["avg_crimes_per_month"] = round(float(df.groupby("month").size().mean()), 0)
    m["unresolved_pct_overall"] = round(float(df["unresolved_flag"].mean() * 100), 1)
    m["unresolved_pct_by_tier"] = (df.groupby("Crime_Severity_Tier")["unresolved_flag"].mean() * 100).round(1).reindex(tiers).to_dict()
    m["avg_days_to_outcome_by_tier"] = df.groupby("Crime_Severity_Tier")["days_to_outcome"].mean().round(1).reindex(tiers).to_dict()
    m["avg_escalation_by_tier"] = df.groupby("Crime_Severity_Tier")["Case_Escalation_Score"].mean().round(1).reindex(tiers).to_dict()
    m["avg_escalation_by_victim"] = df.groupby("victim_type")["Case_Escalation_Score"].mean().round(1).to_dict()
    by_force_unres = df.groupby("police_force")["unresolved_flag"].mean() * 100
    m["unresolved_pct_force_range"] = [round(float(by_force_unres.min()), 1), round(float(by_force_unres.max()), 1)]
    cv = df.groupby("police_force")["Force_Crime_Volatility_Index"].first()
    m["force_volatility_range"] = [round(float(cv.min()), 1), round(float(cv.max()), 1)]
    m["most_volatile_force"], m["steadiest_force"] = cv.idxmax(), cv.idxmin()
    coded = df["lsoa_code"].notna()
    top60 = df.loc[coded, "lsoa_code"].value_counts().head(60).sum()
    m["top_60_lsoa_share_pct"] = round(float(top60 / coded.sum() * 100), 1)
    m["distinct_lsoas"] = int(df["lsoa_code"].nunique())
    m["geo_quality_flag_pct"] = round(float(df["geo_quality_flag"].mean() * 100), 1)
    m["region_labels_corrected"] = int(df["region_corrected_flag"].sum())
    resolved_high = df[(df["Crime_Severity_Tier"] == "High") & df["outcome_month"].notna()
                       & (df["last_outcome_category"] != "Under investigation")]
    m["high_resolved_within_14d_pct"] = round(float((resolved_high["days_to_outcome"] <= 14).mean() * 100), 2)
    m["high_unresolved_backlog_cases"] = int(((df["Crime_Severity_Tier"] == "High") & (df["unresolved_flag"] == 1)).sum())
    # synthetic-geography check: Scotland lies north of ~54.6 N, yet the coordinates ignore the force
    scot = df[(df["police_force"] == "Police Scotland") & df["latitude"].notna()]
    m["police_scotland_cases_south_of_54_6N_pct"] = round(float((scot["latitude"] < 54.6).mean() * 100), 1)
    m["latitude_range_of_geocoded_cases"] = [round(float(df["latitude"].min()), 2), round(float(df["latitude"].max()), 2)]
    m["longitude_range_of_geocoded_cases"] = [round(float(df["longitude"].min()), 2), round(float(df["longitude"].max()), 2)]
    config.REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    (config.REPORTS_DIR / "headline_metrics.json").write_text(json.dumps(m, indent=2, default=str))
    log.info(STEP, "headline metrics saved -> reports/headline_metrics.json")

    # ---- fig 1 : time to outcome vs unresolved share, by tier ------------------------
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6))
    days = df.groupby("Crime_Severity_Tier")["days_to_outcome"].mean().reindex(tiers)
    axes[0].bar(tiers, days.values, color=[TIER_COLOURS[t] for t in tiers])
    for i, v in enumerate(days.values):
        axes[0].text(i, v + 2, f"{v:.0f}", ha="center")
    axes[0].set_title("Avg days from crime to outcome"); axes[0].set_ylabel("days")
    unres = (df.groupby("Crime_Severity_Tier")["unresolved_flag"].mean() * 100).reindex(tiers)
    axes[1].bar(tiers, unres.values, color=[TIER_COLOURS[t] for t in tiers])
    for i, v in enumerate(unres.values):
        axes[1].text(i, v + 1, f"{v:.1f}%", ha="center")
    axes[1].set_ylim(0, 60); axes[1].set_title("% of cases still unresolved"); axes[1].set_ylabel("%")
    _save(fig, "01_severity_time_to_outcome_vs_unresolved.png")

    # ---- fig 2 : monthly volume + % unresolved ---------------------------------------------
    monthly = df.groupby("month").agg(crimes=("record_id", "size"), unresolved=("unresolved_flag", "mean"))
    fig, ax1 = plt.subplots(figsize=(9, 3.8))
    ax1.plot(monthly.index, monthly["crimes"], color=NAVY, lw=2)
    ax1.set_ylabel("Recorded crimes", color=NAVY); ax1.set_ylim(0, monthly["crimes"].max() * 1.15)
    ax2 = ax1.twinx()
    ax2.plot(monthly.index, monthly["unresolved"] * 100, color=ORANGE, lw=2)
    ax2.set_ylabel("% unresolved", color=ORANGE); ax2.set_ylim(0, 60); ax2.spines["right"].set_visible(True)
    ax1.set_title("Monthly recorded crime and % unresolved (all forces)")
    _save(fig, "02_monthly_crimes_and_unresolved.png")

    # ---- fig 3 : crime type x region heatmap -------------------------------------------------
    heat = pd.crosstab(df["crime_type"], df["police_force_region"])
    heat = heat.loc[heat.sum(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots(figsize=(10, 5.5))
    im = ax.imshow(heat.values, cmap="OrRd", aspect="auto")
    ax.set_xticks(range(heat.shape[1])); ax.set_xticklabels(heat.columns, rotation=35, ha="right")
    ax.set_yticks(range(heat.shape[0])); ax.set_yticklabels(heat.index)
    ax.set_title("Recorded crimes: crime type x region"); fig.colorbar(im, ax=ax, shrink=0.8)
    _save(fig, "03_crime_type_by_region_heatmap.png")

    # ---- fig 5 : volatility by force ----------------------------------------------------------
    cv_sorted = cv.sort_values()
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.barh(cv_sorted.index, cv_sorted.values, color=[RED if v > cv.mean() else TEAL for v in cv_sorted.values])
    ax.axvline(cv.mean(), color=GREY, ls="--"); ax.set_xlabel("CV of monthly crime counts (%)")
    ax.set_title("Force Crime Volatility Index (red = above network average)")
    _save(fig, "04_force_volatility_index.png")
    return m


def export_powerbi_checks(df):
    """Numbers the Power BI measures SHOULD show with no slicer selected."""
    network_esc = df["Case_Escalation_Score"].mean()
    network_cv = df["Force_Crime_Volatility_Index"].mean()
    latest, prev = df["month"].max(), (df["month"].max() - pd.DateOffset(months=1))
    rows = []
    for force, g in df.groupby("police_force"):
        unres_types = g.loc[g["unresolved_flag"] == 1, "crime_type"].value_counts()
        top = sorted(unres_types[unres_types == unres_types.max()].index)[-1]          # ties -> last alphabetically (= DAX MAXX)
        cur, pre = int((g["month"] == latest).sum()), int((g["month"] == prev).sum())
        esc = g["Case_Escalation_Score"].mean()
        vol = g["Force_Crime_Volatility_Index"].iloc[0]
        rows.append({
            "police_force": force, "total_crimes": len(g),
            "pct_unresolved": round(g["unresolved_flag"].mean() * 100, 2),
            "avg_escalation_score": round(esc, 2), "volatility_index": round(float(vol), 2),
            "latest_month_crimes": cur, "previous_month_crimes": pre,
            "mom_change_pct": round((cur - pre) / pre * 100, 2),
            "kpi_is_red": bool(esc > network_esc and vol > network_cv),
            "top_unresolved_crime_type": top, "top_unresolved_count": int(unres_types.max()),
        })
    out = pd.DataFrame(rows)
    path = config.PROJECT_ROOT / "powerbi"
    path.mkdir(parents=True, exist_ok=True)
    out.to_csv(path / "expected_values_by_force.csv", index=False)
    backlog = int(((df["Crime_Severity_Tier"] == "High") & (df["unresolved_flag"] == 1)).sum())
    summary = {
        "total_crimes": int(len(df)), "pct_unresolved": round(float(df["unresolved_flag"].mean() * 100), 2),
        "latest_month": f"{latest:%Y-%m}", "latest_month_crimes": int((df["month"] == latest).sum()),
        "previous_month_crimes": int((df["month"] == prev).sum()),
        "network_avg_escalation_score": round(float(network_esc), 2),
        "network_avg_volatility_index": round(float(network_cv), 2),
        "high_severity_unresolved_backlog": backlog,
        "projected_high_severity_cases_resolved_at_5pct": round(backlog * 0.05, 1),
        "projected_high_severity_cases_resolved_at_10pct": round(backlog * 0.10, 1),
        "projected_high_severity_cases_resolved_at_25pct": round(backlog * 0.25, 1),
    }
    (path / "expected_values_network.json").write_text(json.dumps(summary, indent=2))
    log.info(STEP, "Power BI cross-check files saved -> powerbi/expected_values_*")
    return out, summary

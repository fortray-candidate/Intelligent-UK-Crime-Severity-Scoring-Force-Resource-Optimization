"""
STEP 2 - Heuristic anomaly filtering  ("the Intelligent Filter")
=================================================================
Detects geographically impossible records and moves them OUT of the main
dataset into quarantined_crime_data.csv.

  Rule 1  COORDINATES_OUTSIDE_UK   latitude outside 49-61 OR longitude outside -8.5 to 2
  Rule 2  MALFORMED_LSOA_CODE      lsoa_code present but not 'E01' + exactly 6 digits
                                   (after upper-casing, so e01030134 is repaired, not rejected)

DESIGN DECISION - missing is not the same as impossible
  A blank coordinate or blank LSOA code cannot be tested, so those rows STAY in
  the main table and are marked `geo_quality_flag = 1` (Step 4). This also keeps the
  brief internally consistent: SQL Query 1 needs records that "carry a geocoding-quality
  flag", which could not exist if every flagged row had been quarantined.

The quarantine file keeps the ORIGINAL text of each rejected row plus the reason(s).
"""
import pandas as pd

import config
from pipeline_log import log

STEP = "STEP 2 anomaly filter"


def run(df, raw):
    lat, lon, lsoa = df["latitude"], df["longitude"], df["lsoa_code"]
    reasons = pd.DataFrame(index=df.index)
    reasons["COORDINATES_OUTSIDE_UK"] = (
        (lat.notna() & ~lat.between(config.UK_LAT_MIN, config.UK_LAT_MAX))
        | (lon.notna() & ~lon.between(config.UK_LON_MIN, config.UK_LON_MAX))
    )
    reasons["MALFORMED_LSOA_CODE"] = lsoa.notna() & ~lsoa.str.fullmatch(config.LSOA_PATTERN).fillna(False)

    for name in reasons.columns:
        log.metric(STEP, f"rows failing {name}", int(reasons[name].sum()))
    log.metric(STEP, "rows failing both rules", int(reasons.all(axis=1).sum()))
    log.metric(STEP, "blank coordinates kept (flagged later)", int((lat.isna() | lon.isna()).sum()))
    log.metric(STEP, "blank LSOA codes kept (flagged later)", int(lsoa.isna().sum()))

    is_bad = reasons.any(axis=1)
    bad_src = df.loc[is_bad, "source_row_number"]
    audit = raw[raw["source_row_number"].isin(bad_src)].copy()
    reason_text = reasons.loc[is_bad].apply(lambda r: "; ".join(r.index[r.values]), axis=1)
    reason_text.index = df.loc[is_bad, "source_row_number"].values
    audit["quarantine_reason"] = audit["source_row_number"].map(reason_text)
    audit = audit.sort_values("source_row_number")
    config.QUARANTINE_CSV.parent.mkdir(parents=True, exist_ok=True)
    audit.to_csv(config.QUARANTINE_CSV, index=False)

    clean = df.loc[~is_bad].reset_index(drop=True)
    log.metric(STEP, "rows quarantined", int(is_bad.sum()))
    log.metric(STEP, "rows continuing to the main dataset", len(clean))
    log.info(STEP, f"quarantine file written -> {config.QUARANTINE_CSV.name}")
    return clean, audit

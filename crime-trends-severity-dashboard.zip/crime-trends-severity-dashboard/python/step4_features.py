"""
STEP 4 - Advanced programmatic analysis (feature engineering)
==============================================================
Fully vectorised (no .apply() / lambda loops).

Analysis A  Case_Escalation_Score (0-100, higher = needs more attention)
            start 50
            + 30  Crime_Severity_Tier = High
            + 15  Crime_Severity_Tier = Medium
            + 20  last_outcome_category blank or 'Under investigation'
            - 10  victim_type = Business
            then clipped to 0-100

Analysis B  Force_Crime_Volatility_Index
            Coefficient of Variation of MONTHLY crime counts per force:
            (std / mean) x 100  (sample std, ddof = 1), mapped onto every row.

Helper columns used by SQL / Power BI
            unresolved_flag   1 = outcome blank or 'Under investigation'
            geo_quality_flag  1 = coordinates missing OR LSOA code missing
            days_to_outcome   days from the crime month to the outcome month
"""
import numpy as np
import pandas as pd

import config
from pipeline_log import log

STEP = "STEP 4 features"


def run(df):
    unresolved = df["last_outcome_category"].isna() | df["last_outcome_category"].eq("Under investigation")

    score = (config.ESCALATION_BASE
             + config.ESCALATION_HIGH_BONUS * df["Crime_Severity_Tier"].eq("High")
             + config.ESCALATION_MEDIUM_BONUS * df["Crime_Severity_Tier"].eq("Medium")
             + config.ESCALATION_UNRESOLVED_BONUS * unresolved
             - config.ESCALATION_BUSINESS_PENALTY * df["victim_type"].eq("Business"))
    df["Case_Escalation_Score"] = np.clip(score.astype(int), 0, 100)
    log.metric(STEP, "average Case_Escalation_Score", round(float(df["Case_Escalation_Score"].mean()), 2))

    monthly = df.groupby(["police_force", "month"]).size().rename("crimes").reset_index()
    stats = monthly.groupby("police_force")["crimes"].agg(["mean", "std"])
    cv = (stats["std"] / stats["mean"] * 100).round(2)
    df["Force_Crime_Volatility_Index"] = df["police_force"].map(cv)
    log.info(STEP, f"force CV of monthly counts: min {cv.min():.1f}%  max {cv.max():.1f}%  "
                   f"(most volatile: {cv.idxmax()}, steadiest: {cv.idxmin()})")
    log.metric(STEP, "months in the data window", int(df["month"].nunique()))

    df["unresolved_flag"] = unresolved.astype(int)
    df["geo_quality_flag"] = (df["latitude"].isna() | df["longitude"].isna() | df["lsoa_code"].isna()).astype(int)
    df["days_to_outcome"] = (df["outcome_month"] - df["month"]).dt.days.astype("Int64")
    log.metric(STEP, "unresolved cases (%)", round(float(unresolved.mean() * 100), 2))
    log.metric(STEP, "records with a geocoding-quality flag (%)", round(float(df["geo_quality_flag"].mean() * 100), 2))
    return df
